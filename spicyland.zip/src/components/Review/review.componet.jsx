import React from "react";

const Review = () => {
    return (
        <div>
            <h1>Review!</h1>
        </div>
    )
}

export default Review