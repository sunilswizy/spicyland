const directory_data = [
    {
      title: 'pizza',
      imageUrl: 'https://i.ibb.co/M2nSdsr/pizza.jpg',
      id: 1,
      linkUrl: 'menu/pizza'
    },
    {
      title: 'noodeels',
      imageUrl: 'https://i.ibb.co/nmszds5/noodles.jpg',
      id: 2,
      linkUrl: 'menu/noodles'
    },
    {
      title: 'biriyani',
      imageUrl: 'https://i.ibb.co/rxmtwWD/biriyani.jpg',
      id: 3,
      linkUrl: 'menu/biriyani'
    },
    {
      title: 'icecream',
      imageUrl: 'https://i.ibb.co/hXv9zWm/ice-cream.jpg',
      size: 'large',
      id: 4,
      linkUrl: 'menu/icecream'
    },
    {
      title: 'juice',
      imageUrl: 'https://i.ibb.co/5hKzXwv/juice.jpg',
      size: 'large',
      id: 5,
      linkUrl: 'menu/juice'
    }
  ]

  export default directory_data