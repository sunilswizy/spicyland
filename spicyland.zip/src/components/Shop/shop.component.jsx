import React from "react";

const Shop = () => {
    return (
        <div>
            <h1>Shop</h1>
        </div>
    )
} 

export default Shop