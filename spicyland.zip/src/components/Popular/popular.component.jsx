import React from "react";

const Popular = () => {
    return (
        <div>
            <h1>Popular</h1>
        </div>
    )
}

export default Popular